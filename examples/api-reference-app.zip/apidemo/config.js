exports.appKey = 'MY_APPLICATION_ID';
exports.ecobeeHost = 'www.ecobee.com';
exports.ecobeePort = '443';
exports.isHTTPS = true;
exports.scope = 'smartWrite';
