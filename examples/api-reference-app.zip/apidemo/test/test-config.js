exports.appKey = 'c87fjXJHnTu0xfRGBmgVlOhPy6zoRQ2H';
exports.ecobeeHost = 'localhost';
exports.ecobeePort = '8080';
exports.scope = 'smartWrite';
exports.isHTTPS = false;
exports.test = {
	thermostatId : '145561156354'
}